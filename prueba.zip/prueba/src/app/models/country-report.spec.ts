import { CountryReport } from './country-report';

describe('CountryReport', () => {
  it('should create an instance', () => {
    expect(new CountryReport()).toBeTruthy();
  });
});
