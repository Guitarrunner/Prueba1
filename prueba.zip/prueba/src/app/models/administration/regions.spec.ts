import { Regions } from './regions';

describe('Regions', () => {
  it('should create an instance', () => {
    expect(new Regions()).toBeTruthy();
  });
});
