import { Hospitals } from './hospitals';

describe('Hospitals', () => {
  it('should create an instance', () => {
    expect(new Hospitals()).toBeTruthy();
  });
});
