export class States {
    idEstado:number;
    estado:string;
    constructor(id,state){
        this.idEstado=id;
        this.estado=state;
    }

}
