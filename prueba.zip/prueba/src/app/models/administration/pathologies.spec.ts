import { Pathologies } from './pathologies';

describe('Pathologies', () => {
  it('should create an instance', () => {
    expect(new Pathologies()).toBeTruthy();
  });
});
