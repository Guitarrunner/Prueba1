import { parseHTML } from 'jquery';

export class Contacts {
    idContacto:number;
    nombreContacto:string;
    apellidos:string;
    id:string;
    edad:number;
    nacionalidad:string;
    direccion:string;
    patologias:string;
    email: string;
    idPaciente: number;

    constructor(id,name,lasName,contactId,age,nationality,address,pathologies,email, paciente){
        this.idContacto=id;
        this.nombreContacto = name;
        this.apellidos = lasName;
        this.id=contactId;
        this.edad = age;
        this.nacionalidad = nationality;
        this.direccion = address;
        this.patologias = pathologies;
       this.email = email;
        this.idPaciente = paciente;
    }

}
