import { Contacts } from './contacts';

describe('Contacts', () => {
  it('should create an instance', () => {
    expect(new Contacts()).toBeTruthy();
  });
});
