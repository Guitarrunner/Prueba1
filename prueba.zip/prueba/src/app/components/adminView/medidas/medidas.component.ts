import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medidas',
  templateUrl: './medidas.component.html',
  styleUrls: ['./medidas.component.css']
})
export class MedidasComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
