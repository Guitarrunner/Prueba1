import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modify-state',
  templateUrl: './modify-state.component.html',
  styleUrls: ['./modify-state.component.css']
})
export class ModifyStateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
