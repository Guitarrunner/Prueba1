import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-hospital',
  templateUrl: './create-hospital.component.html',
  styleUrls: ['./create-hospital.component.css']
})
export class CreateHospitalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
