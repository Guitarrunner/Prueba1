import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modify-hospital',
  templateUrl: './modify-hospital.component.html',
  styleUrls: ['./modify-hospital.component.css']
})
export class ModifyHospitalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
