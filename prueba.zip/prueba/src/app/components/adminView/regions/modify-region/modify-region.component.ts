import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modify-region',
  templateUrl: './modify-region.component.html',
  styleUrls: ['./modify-region.component.css']
})
export class ModifyRegionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
