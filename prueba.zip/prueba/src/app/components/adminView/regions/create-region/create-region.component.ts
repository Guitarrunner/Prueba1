import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-region',
  templateUrl: './create-region.component.html',
  styleUrls: ['./create-region.component.css']
})
export class CreateRegionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
