import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modify-pathology',
  templateUrl: './modify-pathology.component.html',
  styleUrls: ['./modify-pathology.component.css']
})
export class ModifyPathologyComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }

}
